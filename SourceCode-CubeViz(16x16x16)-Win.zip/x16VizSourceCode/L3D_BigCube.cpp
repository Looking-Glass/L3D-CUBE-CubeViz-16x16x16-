/*-------------------------------------------------------------------------
  This library is for L3D 16x16x16 Cube, edited by Samtim on June 2016.

  -------------------------------------------------------------------------
  This file is part of the Adafruit NeoPixel library.

  NeoPixel is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as
  published by the Free Software Foundation, either version 3 of
  the License, or (at your option) any later version.

  NeoPixel is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with NeoPixel.  If not, see
  <http://www.gnu.org/licenses/>.
  -------------------------------------------------------------------------*/

#include "L3D_BigCube.h"

L3D_CubePixel::L3D_CubePixel(uint16_t n) : numLEDs(n), numBytes(n * 3)
{
  if((pixels = (uint8_t *)malloc(numBytes))) {
    memset(pixels, 0, numBytes);
  }
}

L3D_CubePixel::~L3D_CubePixel(){
  if(pixels) free(pixels);
}


void L3D_CubePixel::begin(void) {
//    initCloudButton();
//    initAccelerometer();
    pinMode(D0,OUTPUT);  //PB7
    pinMode(D1,OUTPUT); //PB6
    pinMode(D2,OUTPUT);  //BP5
    pinMode(D3,OUTPUT);  //PB4
    pinMode(A2,OUTPUT);  //PA4
    pinMode(A3,OUTPUT); //PA5
    pinMode(A4,OUTPUT);  //BA6
    pinMode(A5,OUTPUT);  //PA7
 
    pinMode(MICROPHONE,INPUT); 
    pinMode(D7, OUTPUT);
    digitalWrite(D7, HIGH);
}

void L3D_CubePixel::show(){
    uint8_t *ptrA,*ptrB,*ptrC,*ptrD,*ptrE,*ptrF,*ptrG,*ptrH;
    uint8_t mask;
    uint8_t c=0,a=0,b=0,j=0;
   
    GPIOA->BSRRH=0xE0;    //set A3~A5 to low
    GPIOB->BSRRH=0xF0;    //set D0~D4 to low
    GPIOC->BSRRH=0x04;     //set A2 to low
   
    ptrA=pixels;
    ptrB=ptrA+stripPIXEL*3;
    ptrC=ptrB+stripPIXEL*3;
    ptrD=ptrC+stripPIXEL*3;
    ptrE=ptrD+stripPIXEL*3;
    ptrF=ptrE+stripPIXEL*3;
    ptrG=ptrF+stripPIXEL*3;
    ptrH=ptrG+stripPIXEL*3;
   
    delay(1);
    __disable_irq();
 
    uint16_t i=stripPIXEL*3;   //3 BYTES = 1 PIXEL
   
    while(i) { // While bytes left... (3 bytes = 1 pixel)
      i--;
      mask = 0x80; // reset the mask
      j=0;
        // reset the 8-bit counter
      do {
        a=0;
        b=0;
        c=0;
 
//========Set D0~D4, i.e. B7~B4=======
        if ((*ptrA)&mask) b|=0x10;// if masked bit is high
    //    else "nop";
        b<<=1;
        if ((*ptrB)&mask) b|=0x10;// if masked bit is high
    //    else "nop";
        b<<=1;
        if ((*ptrC)&mask) b|=0x10;// if masked bit is high
    //    else "nop";
        b<<=1;
        if ((*ptrD)&mask) b|=0x10;// if masked bit is high
   //     else "nop";
 
//=========Set A2, i.g. C2==========
        if ((*ptrE)&mask) c|=0x04;// if masked bit is high
   //     else "nop";
   
        GPIOA->BSRRL=0xE0;    //set A3~A5 to high
        GPIOB->BSRRL=0xF0;    //set D0~D4 to high
        GPIOC->BSRRL=0x04;    //set A2 to high
       
 
//=========Set A3~A5, i.e. A5~A7========  
        if ((*ptrF)&mask) a|=0x80;// if masked bit is high
        // else "nop";
        a>>=1;
        if ((*ptrG)&mask) a|=0x80;// if masked bit is high
   //     else "nop";
        a>>=1;
        if ((*ptrH)&mask) a|=0x80;// if masked bit is high
 
        a=(~a)&0xE0;
        b=(~b)&0xF0;
        c=(~c)&0x04;
        GPIOA->BSRRH=a;
        GPIOB->BSRRH=b;
        GPIOC->BSRRH=c;
        mask>>=1;
         asm volatile(
            "mov r0, r0" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t" "nop" "\n\t"
            ::: "r0", "cc", "memory");
        GPIOA->BSRRH=0xE0;    //set all to low
        GPIOB->BSRRH=0xF0;    //set all to low
        GPIOC->BSRRH=0x04;    //set all to low        
          // WS2812 spec             700ns HIGH
          // Adafruit on Arduino    (meas. 812ns)
          // This lib on Spark Core (meas. 792ns)
          /*
        if(j<7) {
          asm volatile(
            "mov r0, r0" "\n\t"
            ::: "r0", "cc", "memory");
        }
        */
       
      } while ( ++j < 8 ); // ...one color on a pixel done
      ptrA++;
      ptrB++;
      ptrC++;
      ptrD++;
      ptrE++;
      ptrF++;
      ptrG++;
      ptrH++;
    } // end while(i) ... no more pixels
    __enable_irq();    
}

// Set pixel color from separate R,G,B components:
void L3D_CubePixel::setPixelColor(
 uint16_t n, uint8_t r, uint8_t g, uint8_t b) {
  if(n < numLEDs) {
    if(brightness) { // See notes in setBrightness()
      r = (r * brightness) >> 8;
      g = (g * brightness) >> 8;
      b = (b * brightness) >> 8;
    }
    uint8_t *p = &pixels[n * 3];
    if((type & NEO_COLMASK) == NEO_GRB) { *p++ = g; *p++ = r; }
    else                                { *p++ = r; *p++ = g; }
    *p = b;
  }
}

// Set pixel color from 'packed' 32-bit RGB color:
void L3D_CubePixel::setPixelColor(uint16_t n, uint32_t c) {
  if(n < numLEDs) {
    uint8_t
      r = (uint8_t)(c >> 16),
      g = (uint8_t)(c >>  8),
      b = (uint8_t)c;
    if(brightness) { // See notes in setBrightness()
      r = (r * brightness) >> 8;
      g = (g * brightness) >> 8;
      b = (b * brightness) >> 8;
    }
    uint8_t *p = &pixels[n * 3];
    if((type & NEO_COLMASK) == NEO_GRB) { *p++ = g; *p++ = r; }
    else                                { *p++ = r; *p++ = g; }
    *p = b;
  }
}

// Convert separate R,G,B into packed 32-bit RGB color.
// Packed format is always RGB, regardless of LED strand color order.
uint32_t L3D_CubePixel::Color(uint8_t r, uint8_t g, uint8_t b) {
  return ((uint32_t)r << 16) | ((uint32_t)g <<  8) | b;
}

// Query color from previously-set pixel (returns packed 32-bit RGB value)
uint32_t L3D_CubePixel::getPixelColor(uint16_t n) {

  if(n < numLEDs) {
    uint16_t ofs = n * 3;
    return (uint32_t)(pixels[ofs + 2]) |
      (((type & NEO_COLMASK) == NEO_GRB) ?
        ((uint32_t)(pixels[ofs    ]) <<  8) |
        ((uint32_t)(pixels[ofs + 1]) << 16)
      :
        ((uint32_t)(pixels[ofs    ]) << 16) |
        ((uint32_t)(pixels[ofs + 1]) <<  8) );
  }

  return 0; // Pixel # is out of bounds
}

uint16_t L3D_CubePixel::numPixels(void) {
  return numLEDs;
}

// Adjust output brightness; 0=darkest (off), 255=brightest.  This does
// NOT immediately affect what's currently displayed on the LEDs.  The
// next call to show() will refresh the LEDs at this level.  However,
// this process is potentially "lossy," especially when increasing
// brightness.  The tight timing in the WS2811/WS2812 code means there
// aren't enough free cycles to perform this scaling on the fly as data
// is issued.  So we make a pass through the existing color data in RAM
// and scale it (subsequent graphics commands also work at this
// brightness level).  If there's a significant step up in brightness,
// the limited number of steps (quantization) in the old data will be
// quite visible in the re-scaled version.  For a non-destructive
// change, you'll need to re-render the full strip data.  C'est la vie.
void L3D_CubePixel::setBrightness(uint8_t b) {
  // Stored brightness value is different than what's passed.
  // This simplifies the actual scaling math later, allowing a fast
  // 8x8-bit multiply and taking the MSB.  'brightness' is a uint8_t,
  // adding 1 here may (intentionally) roll over...so 0 = max brightness
  // (color values are interpreted literally; no scaling), 1 = min
  // brightness (off), 255 = just below max brightness.
  uint8_t newBrightness = b + 1;
  if(newBrightness != brightness) { // Compare against prior value
    // Brightness has changed -- re-scale existing data in RAM
    uint8_t  c,
            *ptr           = pixels,
             oldBrightness = brightness - 1; // De-wrap old brightness value
    uint16_t scale;
    if(oldBrightness == 0) scale = 0; // Avoid /0
    else if(b == 255) scale = 65535 / oldBrightness;
    else scale = (((uint16_t)newBrightness << 8) - 1) / oldBrightness;
    for(uint16_t i=0; i<numBytes; i++) {
      c      = *ptr;
      *ptr++ = (c * scale) >> 8;
    }
    brightness = newBrightness;
  }
}


Cube::Cube(unsigned int s, unsigned int mb) : \
    maxBrightness(mb),
    strip(L3D_CubePixel(PIXEL_COUNT)),
    size(s)
{ }

/** Construct a new cube with default settings.
  @param s Size of one side of the cube in number of LEDs.
  @param mb Maximum brightness value. Used to prevent the LEDs from drawing too much current (which causes the colors to distort).

  @return A new Cube object.
  */

/*
Cube::Cube() : \
    maxBrightness(50),
    strip(L3D_CubePixel(PIXEL_COUNT)),
    size(16)
{ }
*/

/** Initialization of cube resources and environment. */
void Cube::begin(void) {
 // Serial.begin(115200);
  strip.begin();
//  center=Point((size-1)/2,(size-1)/2,(size-1)/2);  

}

/** Set a voxel at a position to a color.

  @param x, y, z Coordinate of the LED to set.
  @param col Color to set the LED to.
  */
void Cube::setVoxel(int x, int y, int z, Color col)
{
  if(x >= 0 && y >= 0 && z >= 0 &&
      x < this->size && y < this->size && z < this->size) {
    int index = (z*this->size*this->size) + (x*this->size) + y;
    strip.setPixelColor(index, strip.Color(col.red, col.green, col.blue));
  }
}

/** Set a voxel at a position to a color.

  @param index Index of the LED to set.
  @param col Color to set the LED to.
  */
void Cube::setVoxel(int index, Color col)
{
    strip.setPixelColor(index, strip.Color(col.red, col.green, col.blue));
}

/** Set a voxel at a position to a color.

  @param p Coordinate of the LED to set.
  @param col Color to set the LED to.
  */
void Cube::setVoxel(Point p, Color col)
{
  setVoxel(p.x, p.y, p.z, col);
}

/** Get the color of a voxel at a position.

  @param index Coordinate of the LED to get the color from.
  */
Color Cube::getVoxel(int index)
{
    uint32_t col = strip.getPixelColor(index);
	Color pixelColor = Color((col>>16) & 0xff, (col>>8) & 0xff, col & 0xff);
	return pixelColor;
}

/** Get the color of a voxel at a position.

  @param x, y, z Coordinate of the LED to get the color from.
  */
Color Cube::getVoxel(int x, int y, int z)
{
  int index = (z * this->size * this->size) + (x * this->size) + y;
  uint32_t col = strip.getPixelColor(index);
  Color pixelColor = Color((col>>16) & 0xff, (col>>8) & 0xff, col & 0xff);
  return pixelColor;
}

/** Get the color of a voxel at a position.

  @param p Coordinate of the LED to get the color from.
  */
Color Cube::getVoxel(Point p)
{
  return getVoxel(p.x, p.y, p.z);
}

/** Draw a line in 3D space.
  Uses the 3D form of Bresenham's algorithm.

  @param x1, y1, z1 Coordinate of start of line.
  @param x2, y2, z2 Coordinate of end of line.
  @param col Color of the line.
  */
void Cube::line(int x1, int y1, int z1, int x2, int y2, int z2, Color col)
{
  Point currentPoint = Point(x1, y1, z1);

  int dx = x2 - x1;
  int dy = y2 - y1;
  int dz = z2 - z1;
  int x_inc = (dx < 0) ? -1 : 1;
  int l = abs(dx);
  int y_inc = (dy < 0) ? -1 : 1;
  int m = abs(dy);
  int z_inc = (dz < 0) ? -1 : 1;
  int n = abs(dz);
  int dx2 = l << 1;
  int dy2 = m << 1;
  int dz2 = n << 1;

  if((l >= m) && (l >= n)) {
    int err_1 = dy2 - l;
    int err_2 = dz2 - l;

    for(int i = 0; i < l; i++) {
      this->setVoxel(currentPoint, col);

      if(err_1 > 0) {
        currentPoint.y += y_inc;
        err_1 -= dx2;
      }

      if(err_2 > 0) {
        currentPoint.z += z_inc;
        err_2 -= dx2;
      }

      err_1 += dy2;
      err_2 += dz2;
      currentPoint.x += x_inc;
    }
  } else if((m >= l) && (m >= n)) {
    int err_1 = dx2 - m;
    int err_2 = dz2 - m;

    for(int i = 0; i < m; i++) {
      this->setVoxel(currentPoint, col);

      if(err_1 > 0) {
        currentPoint.x += x_inc;
        err_1 -= dy2;
      }

      if(err_2 > 0) {
        currentPoint.z += z_inc;
        err_2 -= dy2;
      }

      err_1 += dx2;
      err_2 += dz2;
      currentPoint.y += y_inc;
    }
  } else {
    int err_1 = dy2 - n;
    int err_2 = dx2 - n;

    for(int i = 0; i < n; i++) {
      this->setVoxel(currentPoint, col);

      if(err_1 > 0) {
        currentPoint.y += y_inc;
        err_1 -= dz2;
      }

      if(err_2 > 0) {
        currentPoint.x += x_inc;
        err_2 -= dz2;
      }

      err_1 += dy2;
      err_2 += dx2;
      currentPoint.z += z_inc;
    }
  }

  this->setVoxel(currentPoint, col);
}

/** Draw a line in 3D space.
  Uses the 3D form of Bresenham's algorithm.

  @param p1 Coordinate of start of line.
  @param p2 Coordinate of end of line.
  @param col Color of the line.
  */
void Cube::line(Point p1, Point p2, Color col)
{
  line(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, col);
}

/** Draw a filled sphere.

  @param x, y, z Position of the center of the sphere.
  @param r Radius of the sphere.
  @param col Color of the sphere.
  */
void Cube::sphere(int x, int y, int z, int r, Color col)
{
  for(int dx = -r; dx <= r; dx++) {
    for(int dy = -r; dy <= r; dy++) {
      for(int dz = -r; dz <= r; dz++) {
        if(sqrt(dx*dx + dy*dy + dz*dz) <= r) {
          setVoxel(x + dx, y + dy, z + dz, col);
        }
      }
    }
  }
}

/** Draw a filled sphere.

  @param p Position of the center of the sphere.
  @param r Radius of the sphere.
  @param col Color of the sphere.
  */
void Cube::sphere(Point p, int r, Color col)
{
  sphere(p.x, p.y, p.z, r, col);
}

/** Draw a shell (empty sphere).

  @param x Position of the center of the shell.
  @param y Position of the center of the shell.
  @param z Position of the center of the shell.
  @param r Radius of the shell.
  @param col Color of the shell.
*/
void Cube::shell(float x, float y,float z, float r, Color col)
{
  float thickness =0.1;
  for(int i=0;i<size;i++)
    for(int j=0;j<size;j++)
      for(int k=0;k<size;k++)
	if(abs(sqrt(pow(i-x,2)+pow(j-y,2)+pow(k-z,2))-r)<thickness)
	  setVoxel(i,j,k,col);
}

/** Draw a shell (empty sphere).

  @param x Position of the center of the shell.
  @param y Position of the center of the shell.
  @param z Position of the center of the shell.
  @param r Radius of the shell.
  @param thickness Thickness of the shell.
  @param col Color of the shell.
*/
void Cube::shell(float x, float y,float z, float r, float thickness, Color col)
{
  for(int i=0;i<size;i++)
    for(int j=0;j<size;j++)
      for(int k=0;k<size;k++)
	if(abs(sqrt(pow(i-x,2)+pow(j-y,2)+pow(k-z,2))-r)<thickness)
	  setVoxel(i,j,k,col);
}

/** Draw a shell (empty sphere).

  @param p Position of the center of the shell.
  @param r Radius of the shell.
  @param col Color of the shell.
*/
void Cube::shell(Point p, float r, Color col)
{
  shell(p.x, p.y, p.z, r, col);
}

/** Draw a shell (empty sphere).

  @param p Position of the center of the shell.
  @param r Radius of the shell.
  @param thickness Thickness of the shell
  @param col Color of the shell.
*/
void Cube::shell(Point p, float r, float thickness, Color col)
{
  shell(p.x, p.y, p.z, r, thickness, col);
}

/** Set the entire cube to one color.

  @param col The color to set all LEDs in the cube to.
*/
void Cube::background(Color col)
{
  for(int x = 0; x < this->size; x++)
    for(int y = 0; y < this->size; y++)
      for(int z = 0; z < this->size; z++)
        setVoxel(x, y, z, col);
}

/** Map a value into a color.
  The set of colors fades from blue to green to red and back again.

  @param val Value to map into a color.
  @param minVal Minimum value that val will take.
  @param maxVal Maximum value that val will take.

  @return Color from value.
*/
Color Cube::colorMap(float val, float minVal, float maxVal)
{
  const float range = 1024;
  val = range * (val-minVal) / (maxVal-minVal);

  Color colors[6];

  colors[0].red = 0;
  colors[0].green = 0;
  colors[0].blue = this->maxBrightness;

  colors[1].red = 0;
  colors[1].green = this->maxBrightness;
  colors[1].blue = this->maxBrightness;

  colors[2].red = 0;
  colors[2].green = this->maxBrightness;
  colors[2].blue = 0;

  colors[3].red = this->maxBrightness;
  colors[3].green = this->maxBrightness;
  colors[3].blue = 0;

  colors[4].red = this->maxBrightness;
  colors[4].green = 0;
  colors[4].blue = 0;

  colors[5].red = this->maxBrightness;
  colors[5].green = 0;
  colors[5].blue = this->maxBrightness;

  if(val <= range/6)
    return lerpColor(colors[0], colors[1], val, 0, range/6);
  else if(val <= 2 * range / 6)
    return(lerpColor(colors[1], colors[2], val, range / 6, 2 * range / 6));
  else if(val <= 3 * range / 6)
    return(lerpColor(colors[2], colors[3], val, 2 * range / 6, 3*range / 6));
  else if(val <= 4 * range / 6)
    return(lerpColor(colors[3], colors[4], val, 3 * range / 6, 4*range / 6));
  else if(val <= 5 * range / 6)
    return(lerpColor(colors[4], colors[5], val, 4 * range / 6, 5*range / 6));
  else
    return(lerpColor(colors[5], colors[0], val, 5 * range / 6, range));
}

/** Linear interpolation between colors.

  @param a, b The colors to interpolate between.
  @param val Position on the line between color a and color b.
  When equal to min the output is color a, and when equal to max the output is color b.
  @param minVal Minimum value that val will take.
  @param maxVal Maximum value that val will take.

  @return Color between colors a and b.
*/
Color Cube::lerpColor(Color a, Color b, int val, int minVal, int maxVal)
{
  int red = a.red + (b.red-a.red) * (val-minVal) / (maxVal-minVal);
  int green = a.green + (b.green-a.green) * (val-minVal) / (maxVal-minVal);
  int blue = a.blue + (b.blue-a.blue) * (val-minVal) / (maxVal-minVal);

  return Color(red, green, blue);
}

/** Make changes to the cube visible.
  Causes pixel data to be written to the LED strips.
*/
void Cube::show()
{
  strip.show();

}


/** Updates the variables related to the accelerometer
updates accelerometerX, accelerometerY and accelerometerZ, which are directly read from the analog pins, minus 2048 to remove the DC bias

calculates theta and phi, which are the 3D rotation angles
 */
void Cube::initAccelerometer()
{
    FLPrunningAverage[0]=analogRead(X);
    FLPrunningAverage[1]=analogRead(Y);
    FLPrunningAverage[2]=analogRead(Z);
}
 
/** calculate the music frequency and amplitude*/

 Sinewave Cube::getSinewave(int sampleCount){
  Sinewave readSinewave;
  int micSampling[sampleCount];
//  if((micSampling = (int *)malloc(sampleCount))) memset(micSampling, 0, sampleCount);
//  memset(micSampling, 0, sampleCount);
  int positive, negative,cycle,startPoint,endPoint;
  bool positiveFlag,negativeFlag;
  long sinewaveSum=0;
  positive=0;
  negative=0;
  cycle=0;
  startPoint=0;
  endPoint=0;
  positiveFlag=false;
  negativeFlag=false;
  sinewaveSum=0;
  
  setADCSampleTime(1);  // set it to fast analogRead mode
  for(int i=0;i<sampleCount;i++)  micSampling[i]=analogRead(MICROPHONE)-900;  //THIS IS FOR BIG CUBE 0~1.2v INPUT
  
 // for(int i=0;i<1000;i++) Serial.println(analogRead(MICROPHONE));
 // delay(2000);

  for(int i=0;i<sampleCount;i++){
    if(micSampling[i]>15) positive++;
      else if(micSampling[i]<-15) negative++;
      // set 20 as marginal reading
    if((positive>15)&&positiveFlag==false){
      positiveFlag=true;
      negativeFlag=false;
      negative=0;
      cycle++;
      if(cycle==2) startPoint=i;
      endPoint=i;
    }
    if((negative>15)&&negativeFlag==false){
      positiveFlag=false;
      negativeFlag=true;
      positive=0;
      cycle++;
      if(cycle==2) startPoint=i;
      endPoint=i;
    }
   }

 for(int i=startPoint;i<endPoint;i++) sinewaveSum+=abs(micSampling[i]);

 if(endPoint-startPoint>0) readSinewave.amplitude=sinewaveSum/(endPoint-startPoint);
 else readSinewave.amplitude=1;
 if((cycle-1>3)&&(readSinewave.amplitude>50))  readSinewave.timePeriod=(endPoint-startPoint)/cycle-1;
 else readSinewave.timePeriod=35;
  // else readSinewave.timePeriod=45;
  /*
    Serial.println("=========================================");
   Serial.println(startPoint);
   Serial.println(endPoint);
   Serial.println(cycle);
   Serial.println(sinewaveSum);
   Serial.println(readSinewave.amplitude);
   Serial.println(readSinewave.timePeriod);
   
   Serial.println("=========================================");
   */
  return readSinewave;
 }
 
 
 void Cube::initCloudButton()
{
  //set the input mode for the 'connect to cloud' button
  pinMode(BUTTON, INPUT_PULLUP);
  pinMode(MODE, INPUT_PULLUP);
    if(!digitalRead(MODE))  //if the wifi button is held down on boot, do a hard reset.  At any other time, keep the firmware, but try to add new wifi creds
    {
        WiFi.on();
        WiFi.clearCredentials();
        System.factoryReset();
    }
}
 
//checks to see if the 'online/offline' switch is switched
void Cube::checkCloudButton()
{
    if(!digitalRead(MODE))
        WiFi.listen();
}
 
 
void Cube::updateAccelerometer()
{
    accelerometer[0]=analogRead(X);
    accelerometer[1]=analogRead(Y);
    accelerometer[2]=analogRead(Z);
    for(int i=0;i<3;i++)
    {
        totals[i]+=accelerometer[i];   
        //sweet running average algorithm:  average[i+1]=average[i]+(sample[i]-average[i])/NUM_SAMPLES
        //I average over 100 samples, or ~2.5 seconds
        FLPrunningAverage[i]=FLPrunningAverage[i]+((accelerometer[i]-FLPrunningAverage[i])/NUM_SAMPLES);
        whack[i]=false;
    }  
    if(abs(accelerometer[0]-FLPrunningAverage[0])>WHACK_X)
        whack[0]=true;
    if(abs(accelerometer[1]-FLPrunningAverage[1])>WHACK_Y)
        whack[1]=true;
    if(abs(accelerometer[2]-FLPrunningAverage[2])>WHACK_Z)
        whack[2]=true;
    whacked=whack[0] | whack[1] | whack[2];
}

void Cube::setFadeSpeed()
{
    if(autoCycle)
        fadeSpeed=2;
    else
        fadeSpeed=20;
}
 
void Cube::incrementDemo()
 {
     demo++;
     setFadeSpeed();
     fading=true;
     if(demo>=DEMO_ROUTINES)
        demo=0;
 }
 
void Cube::decrementDemo()
 {
     demo--;
     setFadeSpeed();
     fading=true;
     if(demo<0)
        demo=DEMO_ROUTINES-1;
 }
 
int Cube::getTrendAverage(int sampleNum){
  long average=0;
  for(int i=0;i<sampleNum;i++) 
        average+=wholeAverage[i];
      average/=sampleNum;
      return average;
     }
    
int Cube::getAverageAmplitude(int sampleNum){
      int averageMax=0,averageMin=wholeAverage[0];
      for(int i=0;i<sampleNum;i++){
        if(wholeAverage[i]>averageMax) averageMax=wholeAverage[i];
        if(wholeAverage[i]<averageMin) averageMin=wholeAverage[i];
      }
      return(averageMax-averageMin);
     }
    
void Cube::addAverageToChain(int arg){
        for(int i=averageSampleNum-1;i>0;i--)
        wholeAverage[i]=wholeAverage[i-1]; 
        wholeAverage[0]=arg;
     }
     
void Cube::fade()
{
    setFadeSpeed();
    Color voxelColor;
        for(int x=0;x<SIZE;x++)
            for(int y=0;y<SIZE;y++)
                for(int z=0;z<SIZE;z++)
                    {
                        voxelColor=getVoxel(x,y,z);
                        if(voxelColor.red>0)
                            voxelColor.red--;
                        if(voxelColor.green>0)
                             voxelColor.green--;
                        if(voxelColor.blue>0)
                            voxelColor.blue--;
                        setVoxel(x,y,z, voxelColor);    
                    }
}