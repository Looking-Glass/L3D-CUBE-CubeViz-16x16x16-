/*--------------------------------------------------------------------

  This library is for L3D 16x16x16 Cube, edited by Samtim on June 2016.
  
  This file is part of the Adafruit NeoPixel library.

  NeoPixel is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as
  published by the Free Software Foundation, either version 3 of
  the License, or (at your option) any later version.

  NeoPixel is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with NeoPixel.  If not, see
  <http://www.gnu.org/licenses/>.
  --------------------------------------------------------------------*/

#ifndef _L3D_H
#define _L3D_H

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "application.h"

//#include <wirish.h>

// 'type' flags for LED pixels (third parameter to constructor):
#define NEO_RGB     0x00 // Wired for RGB data order
#define NEO_GRB     0x01 // Wired for GRB data order
#define NEO_COLMASK 0x01
#define NEO_KHZ400  0x00 // 400 KHz datastream
#define NEO_KHZ800  0x02 // 800 KHz datastream
#define NEO_SPDMASK 0x02
#define type 0x02

#define uint16_t unsigned int
#define uint8_t unsigned char
#define uint32_t unsigned long
#define boolean bool

// IMPORTANT: Set pixel COUNT, PIN and TYPE
//#define PIXEL_PIN D0
#define totalPIXEL 4096
#define stripPIXEL totalPIXEL/8    //THERE IS FOUR PINS TO DRIVE EACH STRIPS

#define PIXEL_COUNT 4096
#define PIXEL_TYPE NEO_GRB + NEO_KHZ800
#define CUBE_SIZE 16


 //accelerometer pinout
#define X A0
#define Y A1
#define Z A6

#define MICROPHONE A7
#define GAIN_CONTROL D5

#define DEMO_TIME 30000

#define BUTTON D6 //press this button to connect to the internet
#define MODE D4
 
#define SIZE 16
#define PI 3.14159

#define pi                    3.1416
#define colorSpeed            0.005
#define getSinewaveSampleNum  2
 
#define FFTJOY3 0
#define COLORRAIN 1
#define MUSICRING 2
#define BALLOON   3    
#define MUSICTOWER 4
#define GOLDENRAIN 5
#define MUSICFIREWORK 6

#define DEMO_ROUTINES 7
 
/**********************************
 * flip variables *
 * ********************************/
 //accelerometer pinout
#define X A0
#define Y A1
#define Z A6
#define NUM_SAMPLES 100

#define WHACK_X 20
#define WHACK_Y 20
#define WHACK_Z 20



//float micAverage;  

class L3D_CubePixel {

 public:

  // Constructor: number of LEDs, pin number, LED type
  L3D_CubePixel(uint16_t n);
  ~L3D_CubePixel();

  void
    begin(void),
    show(void),
    setPixelColor(uint16_t n, uint8_t r, uint8_t g, uint8_t b),
    setPixelColor(uint16_t n, uint32_t c),
    setBrightness(uint8_t);
  uint16_t
    numPixels(void);
  static uint32_t
    Color(uint8_t r, uint8_t g, uint8_t b);
  uint32_t
    getPixelColor(uint16_t n);

 private:

  const uint16_t
    numLEDs,       // Number of RGB LEDs in strip
    numBytes;      // Size of 'pixels' buffer below
  uint8_t
    brightness,
   *pixels;        // Holds LED color values (3 bytes each)
  uint32_t
    endTime;       // Latch timing reference
};



/**   An RGB color. */
struct Color
{
  unsigned char red, green, blue;

  Color(int r, int g, int b) : red(r), green(g), blue(b) {}
  Color() : red(0), green(0), blue(0) {}
};


/* an Sine Wave */

struct Sinewave
{
int timePeriod;
int amplitude;
};

/**   A point in 3D space.  */
struct Point
{
  float x;
  float y;
  float z;
  Point() : x(0), y(0), z(0) {}
  Point(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}
};

/**   An Integer point in 3D space.  */
struct iPoint
{
  int x;
  int y;
  int z;
  iPoint() : x(0), y(0), z(0) {}
  iPoint(int _x, int _y, int _z) : x(_x), y(_y), z(_z) {}
};

struct Rocket
{
    float x,y,z;
    float xVel, yVel, zVel;
    float gravity;
    Color col; 
    Rocket():x((6-1)/2), y(0), z((6-1)/2), col(Color(255,0,0)){}
};
 
 /*
 struct voxel {
  int x;
  int y;
  int z;

  voxel(int x=0, int y=0, int z=0) : x(x), y(y), z(z)
  {};

  bool operator==(const voxel& v) const
  {
      return (v.x == x && v.y == y && v.z == z);
  };

  bool operator!=(const voxel& v) const
  {
      return (v.x != x || v.y != y || v.z != z);
  };

  double distance(const voxel& v) {
    return sqrt(
      pow((v.x - x), 2) +
      pow((v.y - y), 2) +
      pow((v.z - z), 2)
    );
  };
};
*/

/**   An L3D LED cube.
      Provides methods for drawing in 3D. Controls the LED hardware.
*/
class Cube
{
  private:

    L3D_CubePixel strip;

  public:
    int size;
    int maxBrightness;
    Point center;
    float theta, phi;
    int accelerometerX, accelerometerY, accelerometerZ;
    
    int accelerometer[3];
    int FLPrunningAverage[3];
    long trendAverage, runningAverage;
    int runningPeriod;
    int averageSampleNum, averageAmplitude;

    int wholeAverage[30];
    unsigned int lastDemo=0;
    int timeout=0;
    bool onlinePressed=false;
    bool lastOnline=true;
    int frame;

    int demo=FFTJOY3;
    unsigned long totals[3];
    bool whack[3];
    bool whacked=false;
    bool autoCycle=true;    //start on autocycle by default
    bool fading=false;
    int fadeValue=255;
    int fadeSpeed=2;
  //  int *micSampling;
    Cube(unsigned int s, unsigned int mb);
   // Cube(void);

    void setVoxel(int x, int y, int z, Color col);
	void setVoxel(int index, Color col);
    void setVoxel(Point p, Color col);
    Color getVoxel(int x, int y, int z);
	Color getVoxel(int index);
    Color getVoxel(Point p);
    void line(int x1, int y1, int z1, int x2, int y2, int z2, Color col);
    void line(Point p1, Point p2, Color col);
    void sphere(int x, int y, int z, int r, Color col);
    void sphere(Point p, int r, Color col);
    void shell(float x, float y, float z, float r, Color col);
    void shell(float x, float y, float z, float r, float thickness, Color col);
    void shell(Point p, float r, Color col);
    void shell(Point p, float r, float thickness, Color col);
    void background(Color col);

    Color colorMap(float val, float min, float max);
    Color lerpColor(Color a, Color b, int val, int min, int max);
	Sinewave getSinewave(int sampleCount);

    void begin(void);
    void show(void);
    void listen(void);
    void initCloudButton(void);
    void checkCloudButton(void);
    void onlineOfflineSwitch(void);
    void joinWifi(void);
    void updateNetworkInfo(void);
    void initAccelerometer(void);
    void updateAccelerometer(void);
    void setFadeSpeed(void);
    void incrementDemo(void);
    void decrementDemo(void);
    int getTrendAverage(int sampleNum);
    int getAverageAmplitude(int sampleNum);
    void addAverageToChain(int arg);
    void fade(void);
    
    
};

// common colors
const Color black     = Color(0x00, 0x00, 0x00);
const Color grey      = Color(0x92, 0x95, 0x91);
const Color yellow    = Color(0xff, 0xff, 0x14);
const Color magenta   = Color(0xc2, 0x00, 0x78);
const Color orange    = Color(0xf9, 0x73, 0x06);
const Color teal      = Color(0x02, 0x93, 0x86);
const Color red       = Color(50, 0, 0);
const Color brown     = Color(0x65, 0x37, 0x00);
const Color pink      = Color(0xff, 0x81, 0xc0);
const Color blue      = Color(0, 0, 50);
const Color green     = Color(0, 50, 0);
const Color purple    = Color(0x7e, 0x1e, 0x9c);
const Color white     = Color(30, 30, 30);

#endif